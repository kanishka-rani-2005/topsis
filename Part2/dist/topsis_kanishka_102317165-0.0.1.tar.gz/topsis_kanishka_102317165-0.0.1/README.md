# Topsis-Kanishka-102317165

A Python package to implement TOPSIS (Technique for Order Preference by Similarity to Ideal Solution).

## Installation

```bash
pip install Topsis-Kanishka-102317165
```

# Run using CLI command

topsis data.csv "1,1,1,2" "+,+,-,+" output.csv
